import math
from heapq import heappop, heappush
import pickle


k=5

doc_length = {}
champion_list = {}
scores = {}

heap_flag = 1

# set into a list
def convert(set):
    return sorted(set)


#sort
def sort(list):
    return sorted(list.items(), key=lambda x: x[1], reverse=True)


#power
def power(b , p):
    return math.pow(b ,p)



#logarithm
def logarithm(number , b):
    return math.log(number , b)





def one_word(query):

    docs_res = {}

    if query in inverted_index.keys():
        docs = inverted_index[query]

        for d in docs :
            docs_res[d] = URLs[d]

        return d , docs_res
        
    else :
        return 'Sorry! The Query Does Not Found'




def multi_words(tokens):

    token_relevance = {}

    for token in tokens.split():

        if token in inverted_index.keys():

            for i in inverted_index[token]:
                token_relevance[i] += 1

    token_relevance = sort(token_relevance)
    
    d = list(token_relevance.keys())[0]

    return d,URLs[d]





def C_list(tokens):

    for t in tokens:

        champion_list[t] = {}
        for id in inverted_index[t].keys():

            champion_list[t][id] = inverted_index[t][id] / calculate_doc_length(id)

        champion_list[t] = sort(champion_list[t])

    return champion_list





def calculate_doc_length(id):

    l = 0
    for token in contents[id].split():

        l += power(inverted_index[token][id] , 2)
    
    l= power(l , 1.0/2)

    return l




def calculate_tf(token , id):

    w=0

    tf = token_frequency_inDoc[token][id]
    
    if (tf > 0):
        w = 1 + logarithm(tf , 10)

    return w




def calculate_idf(token):

    N = len(contents)
    df = len(inverted_index[token])

    idf = logarithm((N / df) , 10)
    return idf




def tf_idf(token, id):

    return calculate_tf(token, id) * calculate_idf(token)




def cosine_similarity(query, id):

    result = 0

    for token in query.split():
        if token in contents[id].split():
            result += tf_idf(token, id) * inverted_index[token][id]
    
    result /= doc_length[id]
    return result




def calculate_score(query):
    
    for token in query.split():
        if token in champion_list.keys():
            for j in champion_list[token]:
                id = j[0]
                scores[id] = 0
                if id in scores.keys():
                    scores[id] += cosine_similarity(token,id)




def k_scores(query):

    calculate_score(query)

    best_scores = {}

    if (heap_flag == 1):

        heap = []

        for id in scores.keys():
            heappush(heap, (-scores[id], id))

        for i in range(k):
            max, id = heappop(heap)
            best_scores[id] = -max

    else :
        sorted_scores = sort(scores)
        # for i in range(k):

            


    return best_scores






def main():

    global inverted_index , contents , URLs , token_frequency_inDoc , champion_list
    
    with open("inverted_index.txt", "rb") as fp1:   # Unpickling
        inverted_index = pickle.load(fp1)


    with open("contents.txt", "wb") as fp2:
        contents = pickle.load(fp2)


    with open("URLS.txt", "wb") as fp3:
        URLs = pickle.load(fp3)

    with open("token_frequency_inDoc.txt", "wb") as fp4:
        token_frequency_inDoc = pickle.load(fp4)

    
    with open("tokens.txt", "wb") as fp5:
        tokens = pickle.load(fp5)


    champion_list = C_list(tokens)


    number = input("1:Single Query\n2:Multi Query\n")
    query = input("Please Enter Your Query: ")

    if (int(number)==1):
        print(k_scores(query))

    elif(int(number)==2):
        print(k_scores(query))

    else :
        print('invalid input')



if __name__ == "__main__":
    main()